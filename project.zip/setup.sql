create table public.messages (
  id bigint generated always as identity primary key,
  name text not null check (char_length(name) <= 20),
  text text not null check (char_length(text) <= 2000),
  created_at timestamptz not null default now()
);
alter table public.messages enable row level security;
create policy "read" on public.messages for select to anon using (true);
create policy "write" on public.messages for insert to anon with check (true);
grant select, insert on public.messages to anon;
