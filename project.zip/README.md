# Taklifnoma Android loyihasi

## GitHub Actions orqali APK yig'ish

1. Ushbu arxivni oching.
2. Ichidagi `project.zip` va `.github/workflows/build.yml` fayllarini GitHub repository asosiga joylang.
3. GitHub'da **Actions** bo'limiga o'ting.
4. **APK yig'ish** workflow'ini tanlab, **Run workflow** tugmasini bosing.
5. Build tugagach, workflow run sahifasidagi **Artifacts** bo'limidan `Taklifnoma-APK` faylini yuklab oling.

Workflow `project.zip` ichidan `settings.gradle.kts` faylini topadi va Gradle 8.7 / Java 17 yordamida `assembleDebug` bajaradi.

Eslatma: bu workflow APK'ni GitHub Actions'da yig'adi; bu yerda APK build bajarilgani anglatmaydi.
