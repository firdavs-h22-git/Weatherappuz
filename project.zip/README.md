# Messenger (Telegramga oʻxshash chat) — APK yigʻish

## 1. Baza (bepul, karta shart emas): Supabase
1. https://supabase.com ga kiring (GitHub bilan), "New project" oching.
2. Chapdan "SQL Editor" > New query: `setup.sql` ichidagini qoʻyib Run bosing.
3. Project Settings > API: "Project URL" va "anon / publishable key" ni nusxalang.

## 2. Kalitlarni kiriting
`app/src/main/assets/index.html` ichida `SB_URL` va `SB_KEY` ni almashtiring.

## 3. GitHub
1. Yangi repo oching, shu papkadagi hamma narsani yuklang (`.github` papkasi bilan).
2. Actions > Build APK > Run workflow.
3. Tugagach, Artifacts > messenger-apk dan APK ni yuklab oling.

Eslatma: bepul loyiha 7 kun ishlatilmasa pauza boʻladi (dashboarddan "Restore"). Hozircha chat ochiq, parolsiz; jiddiy foydalanishdan oldin autentifikatsiya qoʻshing.
