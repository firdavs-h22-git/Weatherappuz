package uz.toyona.taklifnoma

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** assets/template.html ichidagi __CONFIG__ va __TITLE__ o'rniga kiritilgan qiymatlarni joylaydi. */
object InvitationBuilder {

    fun build(context: Context, v: Map<String, String>): String {
        val template = context.assets.open("template.html")
            .bufferedReader(Charsets.UTF_8)
            .use { it.readText() }

        val groom = v["groom"].orEmpty()
        val bride = v["bride"].orEmpty()
        val date = v["date"].orEmpty().ifEmpty { "2027-08-22" }
        val time = v["time"].orEmpty().ifEmpty { "18:00" }

        val cfg = JSONObject()
        cfg.put("groom", groom)
        cfg.put("bride", bride)
        // O'zbekiston vaqti: UTC+05:00
        cfg.put("start", "${date}T${time}:00+05:00")
        cfg.put("venue", v["venue"].orEmpty())
        cfg.put("address", v["address"].orEmpty())
        cfg.put("landmark", v["landmark"].orEmpty())
        cfg.put("hosts", v["hosts"].orEmpty())
        cfg.put("phone", v["phone"].orEmpty())
        cfg.put("guest", v["guest"].orEmpty())
        cfg.put("link", v["link"].orEmpty())
        cfg.put("program", parseProgram(v["program"].orEmpty()))
        cfg.put("photos", parsePhotos(v["photos"].orEmpty()))

        // </script> ketma-ketligi sahifani buzmasligi uchun
        val json = cfg.toString().replace("</", "<\\/")
        val title = escapeHtml("$groom va $bride to'yi")

        return template.replace("__TITLE__", title).replace("__CONFIG__", json)
    }

    private fun parseProgram(text: String): JSONArray {
        val rows = JSONArray()
        text.lines()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .forEach { line ->
                val parts = line.split("|").map { it.trim() }
                val row = JSONArray()
                row.put(parts.getOrElse(0) { "" })
                row.put(parts.getOrElse(1) { "" })
                row.put(parts.getOrElse(2) { "" })
                rows.put(row)
            }
        return rows
    }

    /** Har qator: "https://.../1.jpg | izoh" -> ["https://.../1.jpg", "izoh"]. Faqat http/https qabul qilinadi. */
    private fun parsePhotos(text: String): JSONArray {
        val rows = JSONArray()
        text.lines()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .forEach { line ->
                val parts = line.split("|").map { it.trim() }
                val url = parts.getOrElse(0) { "" }
                if (url.startsWith("http://") || url.startsWith("https://")) {
                    val row = JSONArray()
                    row.put(url)
                    row.put(parts.getOrElse(1) { "" })
                    rows.put(row)
                }
            }
        return rows
    }

    private fun escapeHtml(s: String): String =
        s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    /** Fayl nomi uchun: "Sardorbek", "Diyoraxon" -> "taklifnoma-sardorbek-diyoraxon.html" */
    fun fileName(v: Map<String, String>): String {
        fun slug(s: String) = s.lowercase()
            .replace(Regex("[^a-z0-9]+"), "-")
            .trim('-')
        val parts = listOf(v["groom"].orEmpty(), v["bride"].orEmpty(), v["guest"].orEmpty())
            .map { slug(it) }
            .filter { it.isNotEmpty() }
        val base = if (parts.isEmpty()) "taklifnoma" else "taklifnoma-" + parts.joinToString("-")
        return "$base.html"
    }
}
