package uz.toyona.taklifnoma

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.util.Base64
import java.io.File
import java.io.InputStream

/** Kuyov/kelin rasmlari va musiqa: ilova xotirasida saqlanadi, taklifnomaga ichiga joylanadi. */
object Media {
    const val GROOM = "groom_photo.jpg"
    const val BRIDE = "bride_photo.jpg"
    const val MUSIC = "music.bin"
    const val MAX_MUSIC_BYTES = 10L * 1024 * 1024
    private const val PHOTO_SIDE = 600
    private const val KEY_MIME = "music_mime"

    private fun file(ctx: Context, name: String) = File(ctx.filesDir, name)

    fun has(ctx: Context, name: String) = file(ctx, name).exists()

    fun delete(ctx: Context, name: String) {
        file(ctx, name).delete()
    }

    fun clear(ctx: Context) {
        listOf(GROOM, BRIDE, MUSIC).forEach { delete(ctx, it) }
    }

    /** Rasmni kvadratga qirqib, 600x600 JPEG qilib saqlaydi. */
    fun savePhoto(ctx: Context, uri: Uri, name: String): Boolean {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return false

            var sample = 1
            while (minOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= PHOTO_SIDE) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return false
            val rotation = ctx.contentResolver.openInputStream(uri)?.use { exifRotation(it) } ?: 0

            val side = minOf(bmp.width, bmp.height)
            val matrix = Matrix()
            if (rotation != 0) matrix.postRotate(rotation.toFloat())
            var square = Bitmap.createBitmap(
                bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side, matrix, true
            )
            if (square.width > PHOTO_SIDE) {
                square = Bitmap.createScaledBitmap(square, PHOTO_SIDE, PHOTO_SIDE, true)
            }
            file(ctx, name).outputStream().use { square.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            true
        } catch (e: Throwable) {
            false
        }
    }

    private fun exifRotation(input: InputStream): Int = try {
        when (ExifInterface(input).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90
            ExifInterface.ORIENTATION_ROTATE_180 -> 180
            ExifInterface.ORIENTATION_ROTATE_270 -> 270
            else -> 0
        }
    } catch (e: Throwable) {
        0
    }

    /** Muvaffaqiyatli bo'lsa null, aks holda xato matnini qaytaradi. */
    fun saveMusic(ctx: Context, uri: Uri): String? {
        val tmp = File(ctx.filesDir, "music.tmp")
        return try {
            val mime = ctx.contentResolver.getType(uri)?.takeIf { it.startsWith("audio/") } ?: "audio/mpeg"
            var total = 0L
            val input = ctx.contentResolver.openInputStream(uri) ?: return "Faylni ochib bo'lmadi"
            input.use { ins ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        total += n
                        if (total > MAX_MUSIC_BYTES) {
                            tmp.delete()
                            return "Musiqa fayli katta. 10 MB dan kichik mp3 tanlang"
                        }
                        out.write(buf, 0, n)
                    }
                }
            }
            file(ctx, MUSIC).delete()
            if (!tmp.renameTo(file(ctx, MUSIC))) return "Saqlab bo'lmadi"
            ctx.getSharedPreferences("taklifnoma", Context.MODE_PRIVATE)
                .edit().putString(KEY_MIME, mime).apply()
            null
        } catch (e: Throwable) {
            tmp.delete()
            "Saqlab bo'lmadi: ${e.message}"
        }
    }

    fun musicMime(ctx: Context): String =
        ctx.getSharedPreferences("taklifnoma", Context.MODE_PRIVATE).getString(KEY_MIME, null) ?: "audio/mpeg"

    /** data: manzil ko'rinishida (taklifnoma ichiga joylash uchun). Fayl yo'q bo'lsa null. */
    fun dataUri(ctx: Context, name: String, mime: String): String? {
        val f = file(ctx, name)
        if (!f.exists()) return null
        return "data:$mime;base64," + Base64.encodeToString(f.readBytes(), Base64.NO_WRAP)
    }
}
