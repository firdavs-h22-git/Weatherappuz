package uz.toyona.taklifnoma

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity

/** Tayyor taklifnomani ilova ichida ko'rsatadi. */
class PreviewActivity : AppCompatActivity() {

    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // HTML katta bo'lishi mumkin (rasm, musiqa), shuning uchun intent orqali emas, fayl orqali olinadi
        val path = intent.getStringExtra(EXTRA_PATH).orEmpty()
        val html = try {
            java.io.File(path).readText(Charsets.UTF_8)
        } catch (e: Exception) {
            ""
        }

        web = WebView(this)
        setContentView(web)

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.settings.allowFileAccess = false
        web.settings.allowContentAccess = false

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url.toString()
                if (url.startsWith(BASE_URL)) return false
                // Xarita, Telegram, kalendar havolalari tashqi ilovada ochiladi
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, request.url))
                } catch (e: ActivityNotFoundException) {
                    // mos ilova yo'q, hech narsa qilmaymiz
                }
                return true
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else finish()
            }
        })

        web.loadDataWithBaseURL(BASE_URL, html, "text/html", "UTF-8", null)
    }

    override fun onPause() {
        web.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }

    companion object {
        const val EXTRA_PATH = "path"
        private const val BASE_URL = "https://taklifnoma.local/"
    }
}
