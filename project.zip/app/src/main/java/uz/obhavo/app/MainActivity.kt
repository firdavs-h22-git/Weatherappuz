package uz.obhavo.app

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var cityInput: EditText
    private lateinit var cityName: TextView
    private lateinit var emoji: TextView
    private lateinit var temp: TextView
    private lateinit var desc: TextView
    private lateinit var feels: TextView
    private lateinit var humidity: TextView
    private lateinit var wind: TextView
    private lateinit var forecastBox: LinearLayout
    private lateinit var statusTv: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        cityInput = findViewById(R.id.cityInput)
        cityName = findViewById(R.id.cityName)
        emoji = findViewById(R.id.emoji)
        temp = findViewById(R.id.temp)
        desc = findViewById(R.id.desc)
        feels = findViewById(R.id.feels)
        humidity = findViewById(R.id.humidity)
        wind = findViewById(R.id.wind)
        forecastBox = findViewById(R.id.forecastBox)
        statusTv = findViewById(R.id.status)

        findViewById<Button>(R.id.searchBtn).setOnClickListener { search() }
        findViewById<Button>(R.id.refreshBtn).setOnClickListener { refresh() }
        cityInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                search()
                true
            } else false
        }

        cityName.text = Store.place(this).first
        refresh()
    }

    private fun refresh() {
        statusTv.setText(R.string.loading)
        Thread { fetch() }.start()
    }

    private fun search() {
        val q = cityInput.text.toString().trim()
        if (q.isEmpty()) return
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(cityInput.windowToken, 0)
        statusTv.setText(R.string.loading)
        Thread {
            try {
                val g = Api.geocode(q)
                if (g == null) {
                    runOnUiThread { statusTv.setText(R.string.not_found) }
                } else {
                    Store.savePlace(this@MainActivity, g.first, g.second, g.third)
                    fetch()
                }
            } catch (e: Exception) {
                runOnUiThread { statusTv.setText(R.string.error) }
            }
        }.start()
    }

    private fun fetch() {
        try {
            val (city, lat, lon) = Store.place(this)
            val w = Api.forecast(lat, lon)
            Store.saveLast(this, w)
            runOnUiThread {
                show(city, w)
                WeatherWidget.redraw(this)
            }
        } catch (e: Exception) {
            runOnUiThread { statusTv.setText(R.string.error) }
        }
    }

    private fun show(city: String, w: Weather) {
        cityName.text = city
        emoji.text = Codes.emoji(w.code)
        temp.text = "${w.temp}°"
        desc.text = Codes.text(w.code)
        feels.text = getString(R.string.feels, w.feels)
        humidity.text = getString(R.string.humidity, w.humidity)
        wind.text = getString(R.string.wind, w.wind)
        statusTv.text = ""

        forecastBox.removeAllViews()
        for (d in w.days) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(0, dp(8), 0, dp(8))

            val name = TextView(this)
            name.text = d.name
            name.setTextColor(Color.WHITE)
            name.textSize = 17f
            row.addView(name, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

            val em = TextView(this)
            em.text = d.emoji
            em.textSize = 22f
            row.addView(em, LinearLayout.LayoutParams(dp(48), LinearLayout.LayoutParams.WRAP_CONTENT))

            val t = TextView(this)
            t.text = "${d.min}° / ${d.max}°"
            t.setTextColor(Color.WHITE)
            t.textSize = 17f
            t.gravity = Gravity.END
            row.addView(t, LinearLayout.LayoutParams(dp(100), LinearLayout.LayoutParams.WRAP_CONTENT))

            forecastBox.addView(row)
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
