package uz.obhavo.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class WeatherWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val pending = goAsync()
        Thread {
            try {
                val (_, lat, lon) = Store.place(context)
                Store.saveLast(context, Api.forecast(lat, lon))
            } catch (e: Exception) {
                // интернет йўқ — сақланган маълумот кўрсатилади
            }
            draw(context, manager, ids)
            pending.finish()
        }.start()
    }

    companion object {
        fun redraw(context: Context) {
            val mgr = AppWidgetManager.getInstance(context)
            val ids = mgr.getAppWidgetIds(ComponentName(context, WeatherWidget::class.java))
            if (ids.isNotEmpty()) draw(context, mgr, ids)
        }

        private fun draw(context: Context, mgr: AppWidgetManager, ids: IntArray) {
            val code = Store.lastCode(context)
            val views = RemoteViews(context.packageName, R.layout.widget)
            views.setTextViewText(R.id.wCity, Store.place(context).first)
            views.setTextViewText(R.id.wTemp, Store.lastTemp(context))
            views.setTextViewText(R.id.wEmoji, if (code >= 0) Codes.emoji(code) else "🌡️")
            views.setTextViewText(R.id.wDesc, if (code >= 0) Codes.text(code) else "")

            val intent = Intent(context, MainActivity::class.java)
            val pi = PendingIntent.getActivity(
                context, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widgetRoot, pi)
            mgr.updateAppWidget(ids, views)
        }
    }
}
