package uz.obhavo.app

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

data class Day(val name: String, val emoji: String, val min: Int, val max: Int)

data class Weather(
    val temp: Int,
    val feels: Int,
    val humidity: Int,
    val wind: Int,
    val code: Int,
    val days: List<Day>
)

object Codes {
    fun text(code: Int): String = when (code) {
        0 -> "Тиниқ осмон"
        1 -> "Асосан очиқ"
        2 -> "Ўзгарувчан булутли"
        3 -> "Булутли"
        45, 48 -> "Туман"
        in 51..55 -> "Майда ёмғир"
        56, 57, 66, 67 -> "Музлаган ёмғир"
        in 61..65 -> "Ёмғир"
        in 71..77 -> "Қор"
        in 80..82 -> "Жала"
        85, 86 -> "Қорли жала"
        95 -> "Момақалдироқ"
        96, 99 -> "Дулли момақалдироқ"
        else -> "—"
    }

    fun emoji(code: Int): String = when (code) {
        0 -> "☀️"
        1 -> "🌤️"
        2 -> "⛅"
        3 -> "☁️"
        45, 48 -> "🌫️"
        in 51..55 -> "🌦️"
        56, 57, 66, 67 -> "🌧️"
        in 61..65 -> "🌧️"
        in 71..77 -> "❄️"
        in 80..82 -> "🌦️"
        85, 86 -> "🌨️"
        95, 96, 99 -> "⛈️"
        else -> "🌡️"
    }
}

object Api {
    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 10000
        try {
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    /** Шаҳар номи бўйича (номи, кенглик, узунлик) қайтаради */
    fun geocode(name: String): Triple<String, Double, Double>? {
        val q = URLEncoder.encode(name, "UTF-8")
        val json = JSONObject(
            get("https://geocoding-api.open-meteo.com/v1/search?name=$q&count=1&language=ru&format=json")
        )
        val arr = json.optJSONArray("results") ?: return null
        if (arr.length() == 0) return null
        val r = arr.getJSONObject(0)
        return Triple(r.getString("name"), r.getDouble("latitude"), r.getDouble("longitude"))
    }

    fun forecast(lat: Double, lon: Double): Weather {
        val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
            "&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m" +
            "&daily=weather_code,temperature_2m_max,temperature_2m_min" +
            "&timezone=auto&forecast_days=7"
        val json = JSONObject(get(url))
        val cur = json.getJSONObject("current")
        val daily = json.getJSONObject("daily")
        val times = daily.getJSONArray("time")
        val codes = daily.getJSONArray("weather_code")
        val maxs = daily.getJSONArray("temperature_2m_max")
        val mins = daily.getJSONArray("temperature_2m_min")

        val dayNames = arrayOf("Якшанба", "Душанба", "Сешанба", "Чоршанба", "Пайшанба", "Жума", "Шанба")
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val days = ArrayList<Day>()
        for (i in 0 until times.length()) {
            val name = when (i) {
                0 -> "Бугун"
                1 -> "Эртага"
                else -> {
                    val cal = Calendar.getInstance()
                    cal.time = fmt.parse(times.getString(i))!!
                    dayNames[cal.get(Calendar.DAY_OF_WEEK) - 1]
                }
            }
            days.add(
                Day(
                    name,
                    Codes.emoji(codes.getInt(i)),
                    Math.round(mins.getDouble(i)).toInt(),
                    Math.round(maxs.getDouble(i)).toInt()
                )
            )
        }
        return Weather(
            Math.round(cur.getDouble("temperature_2m")).toInt(),
            Math.round(cur.getDouble("apparent_temperature")).toInt(),
            cur.getInt("relative_humidity_2m"),
            Math.round(cur.getDouble("wind_speed_10m")).toInt(),
            cur.getInt("weather_code"),
            days
        )
    }
}

object Store {
    private fun p(c: Context) = c.getSharedPreferences("obhavo", Context.MODE_PRIVATE)

    fun place(c: Context): Triple<String, Double, Double> {
        val s = p(c)
        return Triple(
            s.getString("city", "Тошкент")!!,
            s.getString("lat", "41.2995")!!.toDouble(),
            s.getString("lon", "69.2401")!!.toDouble()
        )
    }

    fun savePlace(c: Context, city: String, lat: Double, lon: Double) {
        p(c).edit().putString("city", city).putString("lat", lat.toString())
            .putString("lon", lon.toString()).apply()
    }

    fun saveLast(c: Context, w: Weather) {
        p(c).edit().putInt("temp", w.temp).putInt("code", w.code).apply()
    }

    fun lastTemp(c: Context): String =
        if (p(c).contains("temp")) "${p(c).getInt("temp", 0)}°" else "—"

    fun lastCode(c: Context): Int = p(c).getInt("code", -1)
}
